// ゴミの日（追加機能の見本。docs/plugins.md）
//  「燃えるゴミは毎週月曜と木曜」「明日は何ゴミ？」。前の晩と朝に、声で知らせる
//  収集日のルールは data/plugins/gomi.json に保存するので、サーバーを起動し直しても残る
//  祝日・年末年始の変更は扱わない（自治体の案内を見てもらう）
const { createGomi, RULE_PATTERN, TIME_PATTERN, NAME_PATTERN } = require("./gomi-core");

let gomi = null;
// 準備ができる前（start の前・start に失敗したあと）に呼ばれたときは、理由を話せる言葉で断る
const ready = () => { if (!gomi) throw new Error("ゴミの日の準備ができていません"); return gomi; };

module.exports = {
  id: "gomi",
  name: "ゴミの日",
  description: "ゴミの収集日を覚えて、前の晩と朝に声で知らせる",
  prompt: `「燃えるゴミは毎週月曜と木曜」「びん・缶は第2・第4水曜」のように収集日を教えられたら、gomi.set で登録する。
- rule は決まった形で書く。毎週なら「毎週月・木」、第n週なら「第2・4水」（曜日は 月火水木金土日 の1文字、n は 1〜5、区切りは「・」。空白は入れない）。
- 「第2と第4水曜」→ 第2・4水、「月曜と木曜」→ 毎週月・木、のように直す。
- 「明日は何ゴミ？」「今日は？」は gomi.next（day に 今日・明日・明後日）。「次の燃えるゴミはいつ？」は name を使う。
- 知らせの時刻を変えたいと言われたら gomi.settings（時刻は24時間制で 20:00 のように書く）。
- 名前（name）は、空白や句読点を入れない短い言葉にする（知らせの声にそのまま入る）。
- 祝日や年末年始の収集日の変更は扱えない。聞かれたら、自治体の案内を見てもらうよう伝える。`,
  actions: {
    set: {
      description: "ゴミの種類と収集日のルールを登録する（同じ名前は上書き）",
      usage: ['<act do="gomi.set" name="燃えるゴミ" rule="毎週月・木"/>', '<act do="gomi.set" name="びん・缶" rule="第2・4水"/>'],
      params: {
        name: { type: "string", max: 20, pattern: NAME_PATTERN, desc: "ゴミの種類（空白・句読点なし）" },
        rule: { type: "string", max: 20, pattern: RULE_PATTERN, desc: "毎週月・木 か 第2・4水" },
      },
      run: (args) => ready().set(args),
    },
    remove: {
      description: "登録したゴミの種類を消す",
      usage: ['<act do="gomi.remove" name="燃えるゴミ"/>'],
      params: { name: { type: "string", max: 20, pattern: NAME_PATTERN, desc: "ゴミの種類（空白・句読点なし）" } },
      run: (args) => ready().remove(args),
    },
    list: {
      kind: "query",
      description: "登録しているゴミの日と、知らせる時刻",
      run: () => ready().listText(),
    },
    next: {
      kind: "query",
      description: "今日・明日などに出すゴミ、または name の次の収集日を答える（何も書かなければ今日と明日）",
      usage: ['<act do="gomi.next" day="明日"/>', '<act do="gomi.next" name="燃えるゴミ"/>'],
      params: {
        day: { type: "string", optional: true, enum: ["今日", "明日", "明後日"], desc: "今日・明日・明後日" },
        name: { type: "string", optional: true, max: 20, pattern: NAME_PATTERN, desc: "ゴミの種類" },
      },
      run: (args) => ready().nextText(args),
    },
    settings: {
      description: "知らせる時刻（前の晩・朝）とオン／オフを変える（書いた項目だけ変わる）",
      usage: ['<act do="gomi.settings" eveningAt="21:00"/>', '<act do="gomi.settings" morningOn="false"/>'],
      params: {
        eveningAt: { type: "string", optional: true, max: 5, pattern: TIME_PATTERN, desc: "前の晩の時刻 20:00" },
        morningAt: { type: "string", optional: true, max: 5, pattern: TIME_PATTERN, desc: "朝の時刻 7:00" },
        eveningOn: { type: "boolean", optional: true, desc: "前の晩の知らせ true / false" },
        morningOn: { type: "boolean", optional: true, desc: "朝の知らせ true / false" },
      },
      run: (args) => ready().configure(args),
    },
  },
  start(ctx) {
    gomi?.stop();   // 2 回呼ばれても、前の予約を残さない
    gomi = null;
    const g = createGomi({
      store: ctx.store,
      log: { warn: ctx.warn },
      notify: (text) => ctx.notify({ text, chime: "notice" }),
    });
    g.load();
    g.start();
    gomi = g;       // 読み込みと開始が済んでから使えるようにする（失敗したら「準備ができていません」のまま）
  },
  stop() { gomi?.stop(); gomi = null; },
};
