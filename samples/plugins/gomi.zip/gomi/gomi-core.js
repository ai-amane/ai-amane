// ゴミの日の中身（収集日のルールの解釈・日付の計算・知らせる時刻の管理）。plugin.js から使う
//  時計（now）と繰り返し（setTimer / clearTimer）を差し替えられるようにして、テストで時間を進められるようにしている
//  祝日・年末年始の変更は扱わない（自治体の案内を見てもらう）
//  TIME_PATTERN・NAME_PATTERN・名前の選び方は kusuri-core.js にも同じものがある。1 つずつ配る見本なので、わざと同じものを置いている
const MAX_RULES = 20;
const CHECK_MS = 60 * 1000;          // 時刻を見る間隔（PC のスリープからの復帰にも追いつく）
const LATE_MIN = 180;                // 知らせる時刻をこれ以上（分）過ぎていたら、その回は知らせない
                                     // （昼に起動したのに「今日は〜」と言わないため）
const LOOKAHEAD_DAYS = 366;          // 「次の〇〇はいつ？」で先を探す日数（第5〇曜のように、間があく収集日もあるため）
const DEFAULT_SETTINGS = { eveningAt: "20:00", morningAt: "07:00", eveningOn: true, morningOn: true };
const DAY_CHARS = "日月火水木金土";   // Date#getDay() の順（日曜 = 0）

// ルールの書き方（plugin.js の params の pattern にも使う）
//   毎週 月・木 → 「毎週月・木」    第 2・第 4 水 → 「第2・4水」
const DAY = "[月火水木金土日]";
const RULE_PATTERN = `毎週${DAY}(?:・${DAY}){0,6}|第[1-5](?:・[1-5]){0,4}${DAY}`;
const RULE_RE = new RegExp(`^(?:${RULE_PATTERN})$`, "u");
const TIME_PATTERN = "(?:[01]?\\d|2[0-3])[:：][0-5]\\d";
const TIME_RE = new RegExp(`^(?:${TIME_PATTERN})$`, "u");
// ゴミの種類の名前。知らせの声にそのまま入るので、空白・句読点・記号（「・」と英数字は可）は入れさせない
const NAME_PATTERN = "[^\\s!-/:-@\\[-`{-~！？。、，．「」『』（）［］＜＞：；＂＇…]{1,20}";
const NAME_RE = new RegExp(`^(?:${NAME_PATTERN})$`, "u");

const dayIndex = (c) => DAY_CHARS.indexOf(c);
const uniqSorted = (xs) => [...new Set(xs)].sort((a, b) => a - b);

// 「毎週月・木」「第2・4水」を { kind, days | weeks, day } にする。書き方が違えば Error
function parseRule(text) {
  const s = String(text ?? "").trim();
  if (!RULE_RE.test(s)) throw new Error("ルールは「毎週月・木」か「第2・4水」の形で書いてください");
  if (s.startsWith("毎週")) return { kind: "weekly", days: uniqSorted([...s.slice(2)].filter((c) => c !== "・").map(dayIndex)) };
  const m = s.match(/^第([1-5・]+)(.)$/u);
  return { kind: "nth", weeks: uniqSorted(m[1].split("・").map(Number)), day: dayIndex(m[2]) };
}
// ルールを、同じ意味なら同じ文字にそろえる（保存・表示・同じルールの判定に使う）
function formatRule(rule) {
  if (rule.kind === "weekly") return `毎週${rule.days.map((d) => DAY_CHARS[d]).join("・")}`;
  return `第${rule.weeks.join("・")}${DAY_CHARS[rule.day]}`;
}
// 読み上げ用（「毎週 月曜・木曜」「第2・第4 水曜」）
function ruleSpeech(rule) {
  if (rule.kind === "weekly") return `毎週${rule.days.map((d) => `${DAY_CHARS[d]}曜`).join("・")}`;
  return `第${rule.weeks.join("・第")}${DAY_CHARS[rule.day]}曜`;
}

// その月の何回目の曜日か（1 日〜7 日 → 1、8 日〜14 日 → 2 …）
const nthOfMonth = (date) => Math.ceil(date.getDate() / 7);
// その日がルールに当たるか。date は Date（時刻は見ない）
function matches(rule, date) {
  const wd = date.getDay();
  if (rule.kind === "weekly") return rule.days.includes(wd);
  return wd === rule.day && rule.weeks.includes(nthOfMonth(date));
}
// 日付から n 日あとの Date（夏時間のない日本向け。月またぎ・年またぎは Date に任せる）
const addDays = (date, n) => new Date(date.getFullYear(), date.getMonth(), date.getDate() + n);
// 2026-10-15 の形（PC の時刻）
const dayKey = (date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
// "7:00" / "7：00" → "07:00"。全角のコロンも受ける（数字は半角だけ）。形が違えば Error
function normalizeTime(text) {
  const s = String(text ?? "").trim();
  if (!TIME_RE.test(s)) throw new Error("時刻は 20:00 のように書いてください");
  const [h, m] = s.split(/[:：]/);
  return `${h.padStart(2, "0")}:${m}`;
}
const minutesOf = (hhmm) => Number(hhmm.slice(0, 2)) * 60 + Number(hhmm.slice(3));
const timeSpeech = (hhmm) => `${Number(hhmm.slice(0, 2))}時${hhmm.slice(3) === "00" ? "" : `${Number(hhmm.slice(3))}分`}`;

// その日に出すゴミの名前の一覧
function trashOn(rules, date) {
  return rules.filter((r) => matches(parseRule(r.rule), date)).map((r) => r.name);
}
const WORD = { 0: "今日", 1: "明日", 2: "明後日" };

// 名前で選ぶ: まず名前がそのまま合うもの。無ければ名前の一部が合うもの（言われた言葉が 2 字以上のときだけ。1 字が何にでも当たらないように）
function matchByName(list, query) {
  const q = String(query ?? "").trim();
  const exact = list.filter((x) => x.name === q);
  if (exact.length) return exact;
  if (q.length < 2) return [];
  return list.filter((x) => x.name.includes(q) || (x.name.length >= 2 && q.includes(x.name)));
}
// 保存してあったルールとして正しい形か
const validRule = (r) => Boolean(r) && typeof r.name === "string" && NAME_RE.test(r.name) && RULE_RE.test(String(r.rule));
const validTime = (t) => typeof t === "string" && TIME_RE.test(t);

// store: { load, save }  notify(text): 声で知らせる  log: { warn }
//  settings の既定値は DEFAULT_SETTINGS。最後に知らせた日（last）は store に残し、起動し直しても二重に知らせない
function createGomi({ store, notify, now = Date.now, setTimer = setInterval, clearTimer = clearInterval, log = console }) {
  let rules = [];
  let settings = DEFAULT_SETTINGS;
  let last = { evening: "", morning: "" };
  let handle = null;

  const save = () => { try { store.save({ rules, settings, last }); } catch (e) { log.warn("[gomi] 保存できません:", e.message); } };

  // 起動したとき: 前に保存した内容を読み込む（壊れたものは捨てる）
  function load() {
    const saved = store.load({}) || {};
    const seen = new Set();   // 同じ名前は、先に書いてあるほうだけ残す
    rules = (Array.isArray(saved.rules) ? saved.rules : []).filter((r) => validRule(r) && !seen.has(r.name) && seen.add(r.name)).slice(0, MAX_RULES)
      .map((r) => ({ name: r.name, rule: formatRule(parseRule(r.rule)) }));
    const s = saved.settings || {};
    settings = {
      eveningAt: validTime(s.eveningAt) ? normalizeTime(s.eveningAt) : DEFAULT_SETTINGS.eveningAt,
      morningAt: validTime(s.morningAt) ? normalizeTime(s.morningAt) : DEFAULT_SETTINGS.morningAt,
      eveningOn: typeof s.eveningOn === "boolean" ? s.eveningOn : DEFAULT_SETTINGS.eveningOn,
      morningOn: typeof s.morningOn === "boolean" ? s.morningOn : DEFAULT_SETTINGS.morningOn,
    };
    const l = saved.last || {};
    last = { evening: typeof l.evening === "string" ? l.evening : "", morning: typeof l.morning === "string" ? l.morning : "" };
  }

  // 登録する（同じ名前があれば、ルールを置き換える）
  function set({ name, rule }) {
    const n = String(name ?? "").trim();
    if (!n) throw new Error("ゴミの種類（name）を指定してください");
    if (!NAME_RE.test(n)) throw new Error("ゴミの種類は、空白や句読点を入れない20字までの名前にしてください");
    const text = formatRule(parseRule(rule));
    const exists = rules.some((r) => r.name === n);
    if (!exists && rules.length >= MAX_RULES) throw new Error(`ゴミの種類は ${MAX_RULES} 個までです`);
    rules = exists ? rules.map((r) => (r.name === n ? { name: n, rule: text } : r)) : [...rules, { name: n, rule: text }];
    save();
    return { text: `${n}は${ruleSpeech(parseRule(text))}で${exists ? "直し" : "登録し"}ました。` };
  }

  // 名前で選ぶ（一部が合うものが 2 つ以上ならどれか聞き返す）
  function pick(query, ask = "どれか聞いてください") {
    const q = String(query ?? "").trim();
    if (!rules.length) throw new Error("登録しているゴミの日はありません");
    const hit = matchByName(rules, q);
    if (!hit.length) throw new Error(`「${q}」は登録していません（あるのは ${rules.map((r) => r.name).join("・")}）`);
    if (hit.length > 1) throw new Error(`「${q}」に当たるものが${hit.length}つあります（${hit.map((r) => r.name).join("・")}）。${ask}`);
    return hit[0];
  }
  function remove({ name }) {
    const hit = pick(name, "どれを消すか聞いてください");
    rules = rules.filter((r) => r.name !== hit.name);
    save();
    return { text: `${hit.name}を消しました。` };
  }

  function listText() {
    if (!rules.length) return "登録しているゴミの日はありません。";
    const items = rules.map((r) => `${r.name}は${ruleSpeech(parseRule(r.rule))}`);
    const evening = settings.eveningOn ? `前の晩の${timeSpeech(settings.eveningAt)}` : "";
    const morning = settings.morningOn ? `朝の${timeSpeech(settings.morningAt)}` : "";
    const when = [evening, morning].filter(Boolean).join("と");
    return `${items.join("、")}です。${when ? `${when}に知らせます。` : "知らせはどちらもオフです。"}`;
  }

  // 日の言葉（今日・明日・明後日）で、その日のゴミを答える
  function dayText(date0, offset) {
    const names = trashOn(rules, addDays(date0, offset));
    return names.length ? `${WORD[offset]}は${names.join("、")}の日です。` : `${WORD[offset]}は収集の日ではありません。`;
  }
  // 収集日の言い方（今日・明日・それより先は 10月15日（木曜））
  const whenText = (i, d) => (i <= 1 ? WORD[i] : `${d.getMonth() + 1}月${d.getDate()}日（${DAY_CHARS[d.getDay()]}曜）`);
  // 名前を言われたら、次にその収集日になる日（LOOKAHEAD_DAYS 日先まで）
  function nextOf(name, date0) {
    const hit = pick(name);
    const rule = parseRule(hit.rule);
    for (let i = 0; i <= LOOKAHEAD_DAYS; i += 1) {
      const d = addDays(date0, i);
      if (matches(rule, d)) return `${hit.name}は、${whenText(i, d)}です。`;
    }
    return `${hit.name}は、しばらく収集の日がありません。`;
  }
  // day（今日・明日・明後日）か name（ゴミの種類）を答える。何も言われなければ今日と明日
  function nextText({ day, name } = {}) {
    if (!rules.length) throw new Error("登録しているゴミの日はありません。先に登録してください");
    const date0 = new Date(now());
    if (name) return nextOf(name, date0);
    const offsets = day && Object.values(WORD).includes(day) ? [Object.values(WORD).indexOf(day)] : [0, 1];
    return offsets.map((o) => dayText(date0, o)).join("");
  }

  // 知らせる時刻などを変える（書いた項目だけ）
  function configure({ eveningAt, morningAt, eveningOn, morningOn } = {}) {
    const given = (v) => v !== undefined && v !== null && v !== "";   // 空の文字は「指定なし」と同じ
    const next = {
      ...settings,
      ...(eveningAt ? { eveningAt: normalizeTime(eveningAt) } : {}),
      ...(morningAt ? { morningAt: normalizeTime(morningAt) } : {}),
      ...(typeof eveningOn === "boolean" ? { eveningOn } : {}),
      ...(typeof morningOn === "boolean" ? { morningOn } : {}),
    };
    if (![eveningAt, morningAt, eveningOn, morningOn].some(given)) {
      throw new Error("変える項目（前の晩の時刻・朝の時刻・それぞれのオンオフ）を指定してください");
    }
    settings = next;
    save();
    const part = (on, at, label) => (on ? `${label}は${timeSpeech(at)}` : `${label}はオフ`);
    return { text: `${part(settings.eveningOn, settings.eveningAt, "前の晩の知らせ")}、${part(settings.morningOn, settings.morningAt, "朝の知らせ")}にしました。` };
  }

  // 時刻を見て、知らせる回になっていれば知らせる。知らせた回を返す（テスト用）
  //  同じ日には 1 回だけ（last に残す）。LATE_MIN 以上過ぎた回・該当が無い日は知らせない
  function tick() {
    const t = new Date(now());
    const nowMin = t.getHours() * 60 + t.getMinutes();
    const slots = [
      { key: "evening", on: settings.eveningOn, at: settings.eveningAt, offset: 1, head: "明日は" },
      { key: "morning", on: settings.morningOn, at: settings.morningAt, offset: 0, head: "今日は" },
    ];
    const done = [];
    for (const s of slots) {
      const diff = nowMin - minutesOf(s.at);
      if (!s.on || diff < 0 || diff >= LATE_MIN || last[s.key] === dayKey(t)) continue;
      const names = trashOn(rules, addDays(t, s.offset));
      if (!names.length) continue;
      last = { ...last, [s.key]: dayKey(t) };
      save();   // 先に残す（知らせの途中で止まっても、起動し直したあとに二重にならない）
      try { notify(`${s.head}${names.map((n) => `「${n}」`).join("、")}の日です。`); } catch (e) { log.warn("[gomi] 知らせられません:", e.message); }
      done.push(s.key);
    }
    return done;
  }

  // 見張りの中の失敗で止まらないよう、tick の失敗は記録だけして次に進む
  function guardedTick() { try { tick(); } catch (e) { log.warn("[gomi] 時刻を確かめられません:", e.message); } }
  function start() {
    stop();
    guardedTick();
    handle = setTimer(guardedTick, CHECK_MS);
    handle?.unref?.();
  }
  function stop() { if (handle) clearTimer(handle); handle = null; }

  return { load, set, remove, listText, nextText, configure, tick, start, stop, rules: () => rules.slice(), settings: () => settings };
}

module.exports = {
  createGomi, parseRule, formatRule, ruleSpeech, matches, nthOfMonth, dayKey, normalizeTime, trashOn,
  RULE_PATTERN, TIME_PATTERN, NAME_PATTERN, DEFAULT_SETTINGS, MAX_RULES, LATE_MIN, CHECK_MS, LOOKAHEAD_DAYS,
};
